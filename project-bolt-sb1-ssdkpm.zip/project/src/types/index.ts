export interface Player {
  id: string;
  name: string;
  role: 'Batsman' | 'Bowler' | 'All-rounder' | 'Wicket-keeper';
  stats: {
    batting: {
      average: number;
      strikeRate: number;
      centuries: number;
      fifties: number;
    };
    bowling?: {
      average: number;
      economy: number;
      wickets: number;
    };
  };
  recentForm: number; // 0-10 rating
  fitness: number; // 0-10 rating
}

export interface Prediction {
  format: 'Test' | 'ODI' | 'T20';
  venue: string;
  weather: string;
  predictedXI: Player[];
  confidence: number;
}

export interface VenueConditions {
  pitch: string;
  weather: string;
  avgFirstInningsScore: number;
  avgRunRate: number;
}