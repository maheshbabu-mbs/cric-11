import React from 'react';
import { User, Trophy } from 'lucide-react';
import type { Player } from '../types';

interface PredictedTeamProps {
  players: Player[];
  confidence: number;
}

export default function PredictedTeam({ players, confidence }: PredictedTeamProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <Trophy className="w-6 h-6" />
          Predicted Playing XI
        </h2>
        <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
          Confidence: {confidence}%
        </div>
      </div>

      <div className="space-y-4">
        {players.map((player, index) => (
          <div
            key={player.id}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200"
          >
            <div className="flex items-center gap-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h3 className="font-medium text-gray-800">{player.name}</h3>
                <p className="text-sm text-gray-500">{player.role}</p>
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-sm font-medium text-gray-600">
                Avg: {player.stats.batting.average}
              </div>
              <div className="text-xs text-gray-500">
                SR: {player.stats.batting.strikeRate}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}