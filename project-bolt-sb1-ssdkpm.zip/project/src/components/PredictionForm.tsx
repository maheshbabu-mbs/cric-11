import React, { useState } from 'react';
import { CloudSun, MapPin, Cricket } from 'lucide-react';
import type { VenueConditions } from '../types';

interface PredictionFormProps {
  onSubmit: (format: string, conditions: VenueConditions) => void;
}

export default function PredictionForm({ onSubmit }: PredictionFormProps) {
  const [format, setFormat] = useState('ODI');
  const [conditions, setConditions] = useState<VenueConditions>({
    pitch: 'batting',
    weather: 'sunny',
    avgFirstInningsScore: 280,
    avgRunRate: 5.5
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(format, conditions);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-lg shadow-lg max-w-2xl mx-auto">
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <Cricket className="w-6 h-6" />
          Match Conditions
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Format</label>
            <select
              value={format}
              onChange={(e) => setFormat(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="Test">Test</option>
              <option value="ODI">ODI</option>
              <option value="T20">T20</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 flex items-center gap-1">
              <MapPin className="w-4 h-4" /> Pitch Type
            </label>
            <select
              value={conditions.pitch}
              onChange={(e) => setConditions({...conditions, pitch: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="batting">Batting Friendly</option>
              <option value="bowling">Bowling Friendly</option>
              <option value="balanced">Balanced</option>
              <option value="spinning">Spinning Track</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 flex items-center gap-1">
              <CloudSun className="w-4 h-4" /> Weather
            </label>
            <select
              value={conditions.weather}
              onChange={(e) => setConditions({...conditions, weather: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="sunny">Sunny</option>
              <option value="cloudy">Cloudy</option>
              <option value="rainy">Rainy</option>
              <option value="humid">Humid</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Avg First Innings Score</label>
            <input
              type="number"
              value={conditions.avgFirstInningsScore}
              onChange={(e) => setConditions({...conditions, avgFirstInningsScore: Number(e.target.value)})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors duration-200"
      >
        Predict Playing XI
      </button>
    </form>
  );
}