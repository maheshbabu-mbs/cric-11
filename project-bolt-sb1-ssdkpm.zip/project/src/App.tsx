import React, { useState } from 'react';
import PredictionForm from './components/PredictionForm';
import PredictedTeam from './components/PredictedTeam';
import type { Player, Prediction, VenueConditions } from './types';

// Mock data - Replace with actual API calls
const mockPlayers: Player[] = [
  {
    id: '1',
    name: 'Rohit Sharma',
    role: 'Batsman',
    stats: {
      batting: {
        average: 48.5,
        strikeRate: 89.5,
        centuries: 30,
        fifties: 48,
      },
    },
    recentForm: 8,
    fitness: 9,
  },
  // Add more players...
];

function App() {
  const [prediction, setPrediction] = useState<Prediction | null>(null);

  const handlePrediction = (format: string, conditions: VenueConditions) => {
    // Mock prediction - Replace with actual ML model prediction
    setPrediction({
      format: format as 'Test' | 'ODI' | 'T20',
      venue: 'Eden Gardens',
      weather: conditions.weather,
      predictedXI: mockPlayers.slice(0, 11),
      confidence: 85,
    });
  };

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Indian Cricket Team XI Predictor
          </h1>
          <p className="text-lg text-gray-600">
            Predict the optimal playing XI based on conditions and player statistics
          </p>
        </div>

        <div className="space-y-8">
          <PredictionForm onSubmit={handlePrediction} />
          {prediction && (
            <PredictedTeam
              players={prediction.predictedXI}
              confidence={prediction.confidence}
            />
          )}
        </div>
      </div>
    </div>
  );
}